# ez-eda overview
- This library is a collection of simplified functions for visualizing dataframes quickly and easily
- I started this project after needing more refined heatmaps to understanding correlation

## ez correlation plot 
```
from ez_eda import ez_corr_heatmap
```
This function creates a cleaner seaborn-based heatmap to show correlations between numeric features
